
CREATE TABLE IF NOT EXISTS entries (
  id           TEXT PRIMARY KEY,
  code         TEXT NOT NULL,
  title        TEXT NOT NULL,
  summary      TEXT NOT NULL DEFAULT '',
  body         TEXT NOT NULL DEFAULT '',
  section      TEXT NOT NULL,
  ord          INTEGER NOT NULL DEFAULT 0,
  zone         TEXT,
  status       TEXT NOT NULL DEFAULT 'draft',
  review_refs  JSONB NOT NULL DEFAULT '[]'::jsonb,
  source_note  TEXT NOT NULL DEFAULT '',
  version      INTEGER NOT NULL DEFAULT 1,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by   TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS entry_versions (
  id          SERIAL PRIMARY KEY,
  entry_id    TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
  version     INTEGER NOT NULL,
  body        TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'draft',
  changed_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  changed_by  TEXT NOT NULL DEFAULT '',
  proposal_id INTEGER,
  note        TEXT NOT NULL DEFAULT ''
);
CREATE UNIQUE INDEX IF NOT EXISTS entry_versions_unique ON entry_versions(entry_id, version);

CREATE TABLE IF NOT EXISTS proposals (
  id              SERIAL PRIMARY KEY,
  entry_id        TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  type            TEXT NOT NULL DEFAULT 'Change to existing guidance',
  proposed_text   TEXT NOT NULL DEFAULT '',
  rationale       TEXT NOT NULL DEFAULT '',
  urgency         TEXT NOT NULL DEFAULT 'Routine',
  status          TEXT NOT NULL DEFAULT 'open',
  author_email    TEXT NOT NULL,
  author_name     TEXT NOT NULL DEFAULT '',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_by      TEXT NOT NULL DEFAULT '',
  decided_at      TIMESTAMPTZ,
  decision_note   TEXT NOT NULL DEFAULT '',
  applied_version INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS proposals_status ON proposals(status, created_at DESC);

CREATE TABLE IF NOT EXISTS comments (
  id           SERIAL PRIMARY KEY,
  proposal_id  INTEGER NOT NULL REFERENCES proposals(id) ON DELETE CASCADE,
  author_email TEXT NOT NULL,
  author_name  TEXT NOT NULL DEFAULT '',
  text         TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS comments_proposal ON comments(proposal_id, created_at);
